INSERT INTO test2 (id_test2, retezec) VALUES
("1","asdfasfdrgarg")
("2","dsgag")
("3","")
("4","sheosuh")